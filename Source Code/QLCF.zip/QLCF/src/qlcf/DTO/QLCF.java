

package qlcf.DTO;

import qlcf.GUI.DangNhap;
import qlcf.GUI.MENUFORM;



public class QLCF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DangNhap dn = new DangNhap();
        dn.setVisible(true);
    }
    
}
